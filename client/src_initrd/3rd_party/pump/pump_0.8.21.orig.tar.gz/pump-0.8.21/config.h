#ifndef H_PUMP_CONFIG
#define H_PUMP_CONFIG

#include "pump.h"

int readPumpConfig(char * configFile, struct pumpOverrideInfo ** overrides);

#endif
